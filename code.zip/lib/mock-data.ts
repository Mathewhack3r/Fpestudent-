// Mock data for EduRank - Top 10 students

import type { TopStudent } from "./types"

export const TOP_TEN_STUDENTS: TopStudent[] = [
  { name: "Chisom Okafor", matricNumber: "FPE/2021/001", cgpa: 4.85, rank: 1 },
  { name: "Amara Nwosu", matricNumber: "FPE/2021/002", cgpa: 4.78, rank: 2 },
  { name: "Tunde Adeyemi", matricNumber: "FPE/2021/003", cgpa: 4.72, rank: 3 },
  { name: "Jennifer Ekpo", matricNumber: "FPE/2021/004", cgpa: 4.68, rank: 4 },
  { name: "Obinna Eze", matricNumber: "FPE/2021/005", cgpa: 4.65, rank: 5 },
  { name: "Grace Obi", matricNumber: "FPE/2021/006", cgpa: 4.62, rank: 6 },
  { name: "Kingsley Chukwu", matricNumber: "FPE/2021/007", cgpa: 4.58, rank: 7 },
  { name: "Zainab Ahmed", matricNumber: "FPE/2021/008", cgpa: 4.55, rank: 8 },
  { name: "David Okonkwo", matricNumber: "FPE/2021/009", cgpa: 4.52, rank: 9 },
  { name: "Blessing Adebayo", matricNumber: "FPE/2021/010", cgpa: 4.48, rank: 10 },
]

// In-memory storage for demo entries
let demoEntries: any[] = []

export function addEntry(matricNumber: string, rrrNumber: string) {
  const entry = {
    id: Date.now().toString(),
    matricNumber,
    rrrNumber,
    timestamp: new Date().toISOString(),
  }
  demoEntries.push(entry)
  return entry
}

export function getAllEntries() {
  return demoEntries
}

export function clearAllEntries() {
  demoEntries = []
}

export function checkIfTopTen(matricNumber: string): RankCheckResult {
  const student = TOP_TEN_STUDENTS.find((s) => s.matricNumber === matricNumber)
  if (student) {
    return {
      isTopTen: true,
      rank: student.rank,
      cgpa: student.cgpa,
      name: student.name,
    }
  }
  return { isTopTen: false }
}

import type { RankCheckResult } from "./types"
