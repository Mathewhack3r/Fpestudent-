// Type definitions for EduRank application

export interface StudentEntry {
  id: string
  matricNumber: string
  rrrNumber: string
  timestamp: string
}

export interface ApiResponse<T> {
  success: boolean
  data?: T
  message?: string
}

export interface RankCheckResult {
  isTopTen: boolean
  rank?: number
  cgpa?: number
  name?: string
}

export interface TopStudent {
  name: string
  matricNumber: string
  cgpa: number
  rank: number
}
