import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-block bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            For Assignment Only — Demo App
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4 text-balance">EduRank</h1>
          <p className="text-xl text-slate-600 dark:text-slate-300 mb-2 font-semibold">
            Federal Polytechnic Ede Edition
          </p>
          <p className="text-slate-500 dark:text-slate-400">Check Your Highest Score / CGPA Rank</p>
        </div>

        {/* Main Content */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {/* Student Section */}
          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">For Students</h2>
              <p className="text-slate-600 dark:text-slate-300">
                Enter your matric and RRR numbers to check if you're among the top 10 in your class.
              </p>
            </div>
            <div className="space-y-4">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                ✓ Quick verification
                <br />✓ See your rank and CGPA
                <br />✓ Instant results
              </p>
              <Link href="/check" className="block">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Check My Rank</Button>
              </Link>
            </div>
          </Card>

          {/* Admin Section */}
          <Card className="p-8 hover:shadow-lg transition-shadow">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Admin Dashboard</h2>
              <p className="text-slate-600 dark:text-slate-300">
                View all submitted demo entries and manage the system.
              </p>
            </div>
            <div className="space-y-4">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                ✓ View all submissions
                <br />✓ Clear entries
                <br />✓ Protected access
              </p>
              <Link href="/admin" className="block">
                <Button variant="outline" className="w-full bg-transparent">
                  Admin Panel
                </Button>
              </Link>
            </div>
          </Card>
        </div>

        {/* Footer Info */}
        <div className="text-center p-6 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg max-w-2xl mx-auto">
          <p className="text-sm text-yellow-800 dark:text-yellow-200">
            <strong>⚠️ Demo Information:</strong> This is a demonstration application created for academic assignment
            purposes only. No real data is collected or stored permanently.
          </p>
        </div>
      </div>
    </main>
  )
}
