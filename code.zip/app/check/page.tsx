"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function CheckPage() {
  const [matricNumber, setMatricNumber] = useState("")
  const [rrrNumber, setRrrNumber] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const validateForm = () => {
    if (!matricNumber.trim()) {
      setError("Please enter your matric number")
      return false
    }
    if (!rrrNumber.trim()) {
      setError("Please enter your RRR number")
      return false
    }
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!validateForm()) return

    setIsLoading(true)

    try {
      // Submit entry to mock backend
      const entryResponse = await fetch("/api/entries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ matricNumber, rrrNumber }),
      })

      if (!entryResponse.ok) throw new Error("Failed to submit entry")

      // Store in localStorage for result page
      localStorage.setItem("checkResult", JSON.stringify({ matricNumber, rrrNumber }))

      // Redirect to result page with animation delay
      setTimeout(() => {
        router.push("/result")
      }, 800)
    } catch (err) {
      setError("An error occurred. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 py-12">
      <div className="container mx-auto px-4 max-w-md">
        {/* Back Link */}
        <Link href="/" className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline mb-8">
          ← Back to Home
        </Link>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-block bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 px-3 py-1 rounded-full text-xs font-semibold mb-4">
            Demo Only
          </div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Check Your Rank</h1>
          <p className="text-slate-600 dark:text-slate-300">Enter your details to verify</p>
        </div>

        {/* Form Card */}
        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Matric Number Input */}
            <div>
              <label htmlFor="matric" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                Matric Number *
              </label>
              <input
                id="matric"
                type="text"
                placeholder="e.g., FPE/2021/001"
                value={matricNumber}
                onChange={(e) => setMatricNumber(e.target.value)}
                disabled={isLoading}
                aria-label="Matric Number"
                className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>

            {/* RRR Number Input */}
            <div>
              <label htmlFor="rrr" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                RRR Number *
              </label>
              <input
                id="rrr"
                type="text"
                placeholder="e.g., 201X0001X"
                value={rrrNumber}
                onChange={(e) => setRrrNumber(e.target.value)}
                disabled={isLoading}
                aria-label="RRR Number"
                className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 bg-red-100 dark:bg-red-900 border border-red-300 dark:border-red-700 rounded-lg text-red-700 dark:text-red-200 text-sm">
                {error}
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="animate-spin">⏳</span>
                  Verifying...
                </span>
              ) : (
                "Check Result"
              )}
            </Button>
          </form>

          {/* Info Box */}
          <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg text-sm text-slate-600 dark:text-slate-300">
            Enter any matric number from FPE/2021/001 to FPE/2021/010 to see demo results.
          </div>
        </Card>
      </div>
    </main>
  )
}
