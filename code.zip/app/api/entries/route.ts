// API Route for managing demo entries
// Mock backend with in-memory storage

import type { StudentEntry, ApiResponse } from "@/lib/types"

// In-memory storage for demo entries
const demoEntries: StudentEntry[] = []

export async function POST(request: Request): Promise<Response> {
  try {
    const body = await request.json()
    const { matricNumber, rrrNumber } = body

    // Validate inputs
    if (!matricNumber?.trim() || !rrrNumber?.trim()) {
      return Response.json(
        {
          success: false,
          message: "Matric number and RRR number are required",
        } as ApiResponse<null>,
        { status: 400 },
      )
    }

    // Create new entry
    const entry: StudentEntry = {
      id: Date.now().toString(),
      matricNumber: matricNumber.trim(),
      rrrNumber: rrrNumber.trim(),
      timestamp: new Date().toISOString(),
    }

    demoEntries.push(entry)

    console.log("[v0] Mock Backend - New Entry Added:", entry)
    console.log("[v0] Total entries in memory:", demoEntries.length)

    return Response.json({
      success: true,
      data: entry,
      message: "Entry saved successfully",
    } as ApiResponse<StudentEntry>)
  } catch (error) {
    console.error("[v0] API Error:", error)
    return Response.json({ success: false, message: "Failed to process request" } as ApiResponse<null>, { status: 500 })
  }
}

export async function GET(): Promise<Response> {
  try {
    console.log("[v0] Fetching all entries. Current count:", demoEntries.length)

    return Response.json({
      success: true,
      data: demoEntries,
      message: "Entries retrieved successfully",
    } as ApiResponse<StudentEntry[]>)
  } catch (error) {
    console.error("[v0] API Error:", error)
    return Response.json({ success: false, message: "Failed to retrieve entries" } as ApiResponse<null>, {
      status: 500,
    })
  }
}

export async function DELETE(): Promise<Response> {
  try {
    const previousCount = demoEntries.length
    demoEntries.length = 0 // Clear array

    console.log("[v0] Mock Backend - Cleared all entries. Previous count:", previousCount)

    return Response.json({
      success: true,
      data: [],
      message: `Cleared ${previousCount} entries`,
    } as ApiResponse<StudentEntry[]>)
  } catch (error) {
    console.error("[v0] API Error:", error)
    return Response.json({ success: false, message: "Failed to clear entries" } as ApiResponse<null>, { status: 500 })
  }
}
