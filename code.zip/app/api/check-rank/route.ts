// API Route for checking if a student is in Top 10
// Mock rank verification

import { checkIfTopTen } from "@/lib/mock-data"
import type { ApiResponse, RankCheckResult } from "@/lib/types"

export async function GET(request: Request): Promise<Response> {
  try {
    const { searchParams } = new URL(request.url)
    const matricNumber = searchParams.get("matricNumber")

    if (!matricNumber) {
      return Response.json(
        {
          success: false,
          message: "Matric number is required",
        } as ApiResponse<null>,
        { status: 400 },
      )
    }

    // Check if student is in top 10
    const result = checkIfTopTen(matricNumber)

    console.log(
      "[v0] Rank Check - Matric:",
      matricNumber,
      "| Top 10:",
      result.isTopTen,
      "| Rank:",
      result.rank || "N/A",
    )

    return Response.json({
      success: true,
      data: result,
      message: "Rank check completed",
    } as ApiResponse<RankCheckResult>)
  } catch (error) {
    console.error("[v0] API Error:", error)
    return Response.json({ success: false, message: "Failed to check rank" } as ApiResponse<null>, { status: 500 })
  }
}
