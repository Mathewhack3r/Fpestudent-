"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { RankCheckResult } from "@/lib/types"

export default function ResultPage() {
  const [result, setResult] = useState<(RankCheckResult & { matricNumber: string }) | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const storedResult = localStorage.getItem("checkResult")
    if (storedResult) {
      const { matricNumber } = JSON.parse(storedResult)

      // Simulate API call to check rank
      fetch(`/api/check-rank?matricNumber=${matricNumber}`)
        .then((res) => res.json())
        .then((data) => {
          setResult({ ...data, matricNumber })
          setLoading(false)
        })
        .catch(() => {
          setLoading(false)
        })
    } else {
      setLoading(false)
    }
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin text-4xl mb-4">⏳</div>
          <p className="text-slate-600 dark:text-slate-300">Checking your rank...</p>
        </div>
      </main>
    )
  }

  if (!result) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 py-12">
        <div className="container mx-auto px-4 max-w-md text-center">
          <p className="text-red-600 mb-4">Error loading result. Please try again.</p>
          <Link href="/check">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Try Again</Button>
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Back Link */}
        <Link href="/" className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline mb-8">
          ← Back to Home
        </Link>

        {/* Result Card */}
        <Card
          className={`p-8 text-center ${result.isTopTen ? "bg-green-50 dark:bg-green-950" : "bg-slate-50 dark:bg-slate-800"}`}
        >
          <div className="mb-6">
            <div className={`text-5xl mb-4 ${result.isTopTen ? "🎉" : "📊"}`}></div>
            <h1
              className={`text-3xl font-bold mb-4 ${result.isTopTen ? "text-green-700 dark:text-green-300" : "text-slate-700 dark:text-slate-300"}`}
            >
              {result.isTopTen ? "🎊 Congratulations! 🎊" : "Result Information"}
            </h1>
          </div>

          {result.isTopTen ? (
            <div className="space-y-6">
              <div className="bg-white dark:bg-slate-700 p-6 rounded-lg">
                <p className="text-lg text-slate-700 dark:text-slate-300 mb-4">
                  You are among the <span className="font-bold text-green-600 dark:text-green-400">Top 10</span> in your
                  class!
                </p>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="p-4 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <p className="text-sm text-slate-600 dark:text-slate-400">Rank</p>
                    <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">#{result.rank}</p>
                  </div>
                  <div className="p-4 bg-purple-100 dark:bg-purple-900 rounded-lg">
                    <p className="text-sm text-slate-600 dark:text-slate-400">CGPA</p>
                    <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{result.cgpa?.toFixed(2)}</p>
                  </div>
                  <div className="p-4 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                    <p className="text-sm text-slate-600 dark:text-slate-400">Status</p>
                    <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400">✓ Top 10</p>
                  </div>
                </div>

                <div className="border-t border-slate-200 dark:border-slate-600 pt-4">
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                    Student Name: <span className="font-semibold text-slate-900 dark:text-white">{result.name}</span>
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Matric: <span className="font-semibold text-slate-900 dark:text-white">{result.matricNumber}</span>
                  </p>
                </div>
              </div>

              <div className="p-4 bg-green-100 dark:bg-green-900 border border-green-300 dark:border-green-700 rounded-lg">
                <p className="text-sm text-green-800 dark:text-green-200">
                  ✓ Your academic excellence has been verified. Keep up the great work!
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-lg text-slate-700 dark:text-slate-300">
                You are <span className="font-bold">not among the Top 10</span> in your class at this time.
              </p>

              <div className="p-6 bg-white dark:bg-slate-700 rounded-lg">
                <p className="text-slate-600 dark:text-slate-300 mb-4">
                  Matric: <span className="font-semibold text-slate-900 dark:text-white">{result.matricNumber}</span>
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Continue your studies and strive for excellence. You can check your rank again later.
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-4 justify-center mt-8">
            <Link href="/check" className="flex-1">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Check Another</Button>
            </Link>
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full bg-transparent">
                Back Home
              </Button>
            </Link>
          </div>
        </Card>

        {/* Demo Info */}
        <div className="text-center p-4 text-sm text-slate-500 dark:text-slate-400 mt-8">
          <p>For Assignment Demo Purposes Only</p>
        </div>
      </div>
    </main>
  )
}
