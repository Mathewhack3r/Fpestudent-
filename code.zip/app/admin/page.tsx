"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { StudentEntry } from "@/lib/types"

export default function AdminPage() {
  const [passwordInput, setPasswordInput] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [entries, setEntries] = useState<StudentEntry[]>([])
  const [loading, setLoading] = useState(false)
  const [passwordError, setPasswordError] = useState("")

  const ADMIN_PASSWORD = "1111"

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      setPasswordError("")
      loadEntries()
    } else {
      setPasswordError("Incorrect password. Try again.")
      setPasswordInput("")
    }
  }

  const loadEntries = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/entries")
      const data = await response.json()
      setEntries(data.data || [])
    } catch (err) {
      console.error("Failed to load entries:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleClearEntries = async () => {
    if (confirm("Are you sure you want to clear all demo entries? This action cannot be undone.")) {
      try {
        await fetch("/api/entries", { method: "DELETE" })
        setEntries([])
      } catch (err) {
        console.error("Failed to clear entries:", err)
      }
    }
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 py-12">
        <div className="container mx-auto px-4 max-w-md">
          <Link href="/" className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline mb-8">
            ← Back to Home
          </Link>

          <div className="text-center mb-8">
            <div className="inline-block bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 px-3 py-1 rounded-full text-xs font-semibold mb-4">
              Demo Only
            </div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Admin Access</h1>
            <p className="text-slate-600 dark:text-slate-300">Enter password to access the admin panel</p>
          </div>

          <Card className="p-8">
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Admin Password
                </label>
                <input
                  id="password"
                  type="password"
                  placeholder="Enter password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  aria-label="Admin Password"
                  className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {passwordError && (
                <div className="p-4 bg-red-100 dark:bg-red-900 border border-red-300 dark:border-red-700 rounded-lg text-red-700 dark:text-red-200 text-sm">
                  {passwordError}
                </div>
              )}

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                Login
              </Button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg text-sm text-slate-600 dark:text-slate-300">
              <p>
                <strong>Demo Password:</strong> admin123
              </p>
            </div>
          </Card>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link href="/" className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:underline mb-8">
          ← Back to Home
        </Link>

        <div className="text-center mb-8">
          <div className="inline-block bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-200 px-3 py-1 rounded-full text-xs font-semibold mb-4">
            Demo Admin Panel — No Real Data Collected
          </div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Admin Dashboard</h1>
          <p className="text-slate-600 dark:text-slate-300">View all submitted demo entries</p>
        </div>

        <div className="mb-6 flex gap-4 justify-end">
          <Button
            onClick={loadEntries}
            variant="outline"
            disabled={loading}
            className="text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 bg-transparent"
          >
            {loading ? "Loading..." : "Refresh"}
          </Button>
          <Button onClick={handleClearEntries} variant="destructive" className="bg-red-600 hover:bg-red-700 text-white">
            Clear All Entries
          </Button>
        </div>

        <Card className="p-8">
          {entries.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-slate-500 dark:text-slate-400 text-lg">No entries submitted yet.</p>
              <p className="text-slate-400 dark:text-slate-500 text-sm mt-2">
                Students will appear here once they submit the rank check form.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700">
                    <th className="text-left py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">ID</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">
                      Matric Number
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">RRR Number</th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-700 dark:text-slate-300">Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((entry, index) => (
                    <tr
                      key={entry.id}
                      className="border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                    >
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{index + 1}</td>
                      <td className="py-3 px-4 font-mono text-slate-900 dark:text-white">{entry.matricNumber}</td>
                      <td className="py-3 px-4 font-mono text-slate-900 dark:text-white">{entry.rrrNumber}</td>
                      <td className="py-3 px-4 text-sm text-slate-600 dark:text-slate-400">
                        {new Date(entry.timestamp).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg text-sm text-yellow-800 dark:text-yellow-200">
            <p>
              <strong>Total Submissions:</strong> {entries.length}
            </p>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Button
            onClick={() => {
              setIsAuthenticated(false)
              setPasswordInput("")
            }}
            variant="outline"
            className="text-slate-600 dark:text-slate-300"
          >
            Logout
          </Button>
        </div>
      </div>
    </main>
  )
}
